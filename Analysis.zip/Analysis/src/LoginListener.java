public interface LoginListener {
	
	public void loginPerformed(LoginModel event);
}

